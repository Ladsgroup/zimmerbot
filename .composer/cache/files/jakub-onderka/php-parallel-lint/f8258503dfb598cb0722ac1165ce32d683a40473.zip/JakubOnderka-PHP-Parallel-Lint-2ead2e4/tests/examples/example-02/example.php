<?php

$myInteger = 100;
echo $myInteger;
