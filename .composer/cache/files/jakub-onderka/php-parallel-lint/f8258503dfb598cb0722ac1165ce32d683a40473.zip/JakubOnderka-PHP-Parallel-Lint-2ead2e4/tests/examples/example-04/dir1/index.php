<?php
$foo = 'bar';
