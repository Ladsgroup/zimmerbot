<?php

class ExampleClass
{

}
