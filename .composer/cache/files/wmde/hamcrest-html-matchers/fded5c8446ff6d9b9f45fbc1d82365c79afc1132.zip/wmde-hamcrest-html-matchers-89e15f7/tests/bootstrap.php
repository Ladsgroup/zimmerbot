<?php

/** @var $loader \Composer\Autoload\ClassLoader */
$loader = require dirname(__DIR__) . '/vendor/autoload.php';

require_once dirname(__DIR__) . '/src/functions.php';
