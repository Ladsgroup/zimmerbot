<?php

namespace RemexHtml\TreeBuilder;

/**
 * An interface for things that can go in the ActiveFormattingElements list
 */
interface FormattingElement {
}
