<?php

namespace RemexHtml\TreeBuilder;

class TreeBuilderError extends \Exception {
}
