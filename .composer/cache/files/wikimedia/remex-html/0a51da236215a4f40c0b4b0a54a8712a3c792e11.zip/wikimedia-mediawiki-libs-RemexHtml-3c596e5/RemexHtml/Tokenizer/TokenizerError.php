<?php

namespace RemexHtml\Tokenizer;

class TokenizerError extends \Exception {
}
