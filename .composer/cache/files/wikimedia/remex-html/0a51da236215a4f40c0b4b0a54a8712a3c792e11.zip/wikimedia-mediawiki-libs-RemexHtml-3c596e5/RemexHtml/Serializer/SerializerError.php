<?php

namespace RemexHtml\Serializer;

class SerializerError extends \Exception {
}
