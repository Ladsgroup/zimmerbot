# Purtle release notes

## Version 1.0.3 (2016-04-30)
* Ensure correct state when short-circuitting in `RdfWriterBase::about` and `say`.

## Version 1.0.2 (2016-04-29)
* Fixed homepage URL.

## Version 1.0.1 (2016-04-29)
* Fixed PSR-4 class loader for test helpers.

## Version 1.0.0 (2016-04-29)

Initial release
